
const firebaseConfig = {
  apiKey: "AIzaSyDrt7UurMaScbo5Os1orziUmisG6FzXrAI",
  authDomain: "sunnyflo-mini-mart.firebaseapp.com",
  projectId: "sunnyflo-mini-mart",
  storageBucket: "sunnyflo-mini-mart.appspot.com",
  messagingSenderId: "307560320156",
  appId: "1:307560320156:web:a81b68fdbb8dff1b907159",
  measurementId: "G-KEE2HGD09D"
};
firebase.initializeApp(firebaseConfig);
