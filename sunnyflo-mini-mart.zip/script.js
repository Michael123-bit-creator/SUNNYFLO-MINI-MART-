
let userName = "";
function signUp() {
  const name = document.getElementById("name").value;
  const phone = document.getElementById("phone").value;
  const email = document.getElementById("signup-email").value;
  const password = document.getElementById("signup-password").value;
  const confirm = document.getElementById("confirm-password").value;

  if (password !== confirm) return alert("Passwords do not match");

  firebase.auth().createUserWithEmailAndPassword(email, password)
    .then(() => {
      userName = name;
      document.getElementById("signup-form").style.display = "none";
      document.getElementById("login-form").style.display = "block";
      alert("Account created! Please login.");
    })
    .catch(err => alert(err.message));
}

function login() {
  const email = document.getElementById("login-email").value;
  const password = document.getElementById("login-password").value;

  firebase.auth().signInWithEmailAndPassword(email, password)
    .then((userCredential) => {
      const user = userCredential.user;
      const name = userName || email.split("@")[0];
      document.getElementById("auth-section").style.display = "none";
      document.getElementById("dashboard").style.display = "block";
      document.getElementById("welcome-msg").textContent = `WELCOME, ${name.toUpperCase()}`;
    })
    .catch(err => alert("Invalid credentials"));
}

function logout() {
  firebase.auth().signOut().then(() => location.reload());
}
